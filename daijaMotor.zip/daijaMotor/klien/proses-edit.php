<?php
include '../koneksi.php'; // Sertakan file koneksi ke database di sini

// Pastikan variabel-variabel yang diperlukan telah didefinisikan
if(isset($_POST['idklien']) && isset($_POST['namaklien']) && isset($_POST['perusahaanklien']) && isset($_FILES['logoper'])) {

    // Ambil data dari formulir
    $idklien = $_POST['idklien'];
    $namaklien = $_POST['namaklien'];
    $perusahaanklien = $_POST['perusahaanklien'];
    $namafile = $_FILES['logoper']['name']; // Ambil nama file

    // Simpan path file ke dalam database
    $pathGambar = "uploads/" . $namafile;

    // Pindahkan file yang diunggah ke folder uploads
    if(move_uploaded_file($_FILES['logoper']['tmp_name'], $pathGambar)) {
        // Query untuk memperbarui data klien di database
        $sql = "UPDATE klien SET namaklien='$namaklien', perusahaanklien='$perusahaanklien', logoper_path='$pathGambar' WHERE idklien='$idklien'";
        if(mysqli_query($db, $sql)) {
            echo "Data klien berhasil diperbarui.";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($db);
        }
    } else {
        echo "Maaf, terjadi kesalahan saat mengunggah file.";
    }
} else {
    echo "Maaf, terjadi kesalahan dalam pengiriman data.";
}
?>
