<?php
$server = "localhost";
$user = "root";
$password = "";
$nama_database = "db_daija";

$db = mysqli_connect($server, $user, $password, $nama_database);

if (!$db) {
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}

if (isset($_POST['simpan'])) {
    $id_klien = $_POST['idklien'];
    $namaklien = $_POST['namaklien'];
    $perusahaanklien = $_POST['perusahaanklien'];

    // Proses unggah gambar
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["logoper"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Periksa apakah file gambar yang diunggah adalah gambar asli atau palsu
    $check = getimagesize($_FILES["logoper"]["tmp_name"]);
    if ($check !== false) {
        echo "File adalah gambar - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File bukan gambar.";
        $uploadOk = 0;
    }

    // Periksa apakah file sudah ada
    if (file_exists($targetFile)) {
        echo "Maaf, file sudah ada.";
        $uploadOk = 0;
    }

    // Batasi ukuran file
    if ($_FILES["logoper"]["size"] > 500000) {
        echo "Maaf, ukuran file terlalu besar.";
        $uploadOk = 0;
    }

    // Izinkan hanya beberapa format gambar tertentu
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Maaf, hanya file JPG, JPEG, PNG & GIF yang diperbolehkan.";
        $uploadOk = 0;
    }

    // Cek apakah $uploadOk bernilai 0
    if ($uploadOk == 0) {
        echo "Maaf, file tidak diunggah.";
    } else {
        // Jika semuanya berjalan lancar, coba unggah file
        if (move_uploaded_file($_FILES["logoper"]["tmp_name"], $targetFile)) {
            echo "File " . basename($_FILES["logoper"]["name"]) . " berhasil diunggah.";
            // Simpan path gambar ke dalam database
            $pathGambar = $targetFile;

            // Buat query untuk menyimpan data ke database
            $sql = "INSERT INTO klien (idklien, namaklien, perusahaanklien, logoper_path) VALUES ('$id_klien', '$namaklien', '$perusahaanklien', '$pathGambar')";
            if (mysqli_query($db, $sql)) {
                echo "Data berhasil disimpan ke database.";
                header("location:../index.php?p=data-klient");
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($db);
            }
        } else {
            echo "Maaf, terjadi kesalahan saat mengunggah file.";
        }
    }
}
?>
