<?php
$server = "localhost";
$user = "root";
$password = "";
$nama_database = "db_daija";

// Koneksi ke database
$db = mysqli_connect($server, $user, $password, $nama_database);

// Periksa apakah koneksi berhasil
if (!$db) {
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Data Klien</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<div id="label-page">
    <h3>Tampil Data Klien</h3>
</div>

<div id="content">
    <p id="tombol-tambah-container"><a href="../beranda/index.php?p=klien-input" class="tombol">Tambah klien</a></p>
    <br>
    <table id="tabel-tampil">
        <tr>
            <th>ID klien</th>
            <th>Nama Klien</th>
            <th>Perusahaan klien</th>
            <th>Logo klient</th>
            <th>Opsi</th>
        </tr>
        
        <?php
        // Ambil data klien dari database
        $sql = "SELECT * FROM klien ORDER BY idklien";
        $q_tampil_klien = mysqli_query($db, $sql);

        $nomor = 1;
        // Loop untuk menampilkan data klien dalam tabel
        while ($r_tampil_klien = mysqli_fetch_array($q_tampil_klien)) {
        ?>
        <tr>
            <td><?php echo $r_tampil_klien['idklien']; ?></td>
            <td><?php echo $r_tampil_klien['namaklien']; ?></td>
            <td><?php echo $r_tampil_klien['perusahaanklien']; ?></td>
            <td><?php echo $r_tampil_klien['logoper_path']; ?></td>
            <td>
                <div class="tombol-opsi-container">
                    <a href="index.php?p=edit-klien&id=<?php echo $r_tampil_klien['idklien']; ?>" class="tombol">Edit</a>
                </div>
                <div class="tombol-opsi-container">
                    <a href="prosesbuku/klien-hapus.php?id=<?php echo $r_tampil_klien['idklien']; ?>" class="tombol">Hapus</a>
                </div>
            </td>
        </tr>
        <?php
        } // Akhir dari loop
        ?>
    </table>
</div>

</body>
</html>
