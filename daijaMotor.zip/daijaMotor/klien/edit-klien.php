<?php
	$id_klien=$_GET['id'];
	$q_tampil_klien=mysqli_query($db,"SELECT * FROM klien WHERE idklien='$id_klien'");
	$r_tampil_klien=mysqli_fetch_array($q_tampil_klien);
?>
<div id="label-page"><h3>Input Data Klien</h3></div>
<div id="content">
    <form action="input-proses.php" method="post" enctype="multipart/form-data">
        <table id="tabel-input">
            <tr>
                <td class="label-formulir">ID Klien</td>
                <td class="isian-formulir"><input type="text" name="idklien" class="isian-formulir isian-formulir-border"></td>
            </tr>
            <tr>
                <td class="label-formulir">Nama Klien</td>
                <td class="isian-formulir"><input type="text" name="namaklien" class="isian-formulir isian-formulir-border"></td>
            </tr>
            <tr>
                <td class="label-formulir">Perusahaan Klien</td>
                <td class="isian-formulir"><input type="text" name="perusahaanklien" class="isian-formulir isian-formulir-border"></td>
            </tr>
            <tr>
                <td class="label-formulir">Logo Klien</td>
                <td class="isian-formulir"><input type="file" name="logoper" class="isian-formulir isian-formulir-border"></td>
            </tr>
            <tr>
                <td class="label-formulir"></td>
                <td><input type="submit" value="Simpan" class="tombol"></td>
                <td><p id="tombol-tambah-container"><a href="../beranda/index.php?p=proses-edit" class="tombol">Tambah klien</a></p></td>
            </tr>
        </table>
    </form>
</div>
