<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DAIJA MOTOR WEBSITE</title>
    <link rel="stylesheet" type="text/css" href="profile/profile.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="product.css" rel="stylesheet">
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
    <a class="navbar-brand" href="#">
            <img src="../img/th.jpeg" alt="Logo motor" style="max-height: 60px; max-width: 140px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profile/profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../visimisi/visimisi.php">Visi dan Misi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../produk/produk.php">Produk kami</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Kontak Kami</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../about/about.php">About us</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Login</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#">Sign in</a></li>
                        <li><a class="dropdown-item" href="#">Sign up</a></li>
                        <!-- Tambahkan submenu lain sesuai kebutuhan -->
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-light">
  <div class="col-md-5 p-lg-5 mx-auto my-5">
    <h1 class="display-4 font-weight-normal">DAIJAH COMPANY PROFILE</h1>
    <a class="navbar-brand" href="#">
            <img src="../img/PROFILE.jpeg" alt="Logo motor" style="max-height: 560px; max-width: 640px;">
        </a>
    <p class="lead font-weight-normal">Kami di perusahaan kami dengan bangga menawarkan beragam pilihan motor yang memenuhi kebutuhan dan keinginan pelanggan kami.</p>
    <a class="btn btn-outline-secondary" href="../produk/produk.php">Lets See the product</a>
  </div>
 
</div>
<div class="container mt-5">

    <div class="container mt-5">
    <div class="jumbotron">
    <div class="container">
    <div class="container-fluid">
        <img src="../img/gedung.jpeg" class="img-fluid" alt="Responsive image">
    </div>
      <h1 class="display-3">company experience</h1>
          

      <p>Perusahaan telah berdiri dari 2004. Daijah company sudah merakit berbagai jenis motor dan tentunya sudah berpengalaman untuk mewujudkan motor impian anda.
        perusahaan kini sudah menjual lebih dari 50 jenis motor diseluruh dunia. Daijah company kini memiliki 20 cabang di berbagai negara.
        penasaran dengan sejarah perusahaan......
      </p>
      <p><a class="btn btn-primary btn-lg" href="../about/about.php" role="button">lets see &raquo;</a></p>
    </div>
  </div>

  <div class="container mt-5">

    <div class="container mt-5">
    <div class="jumbotron">
    <div class="container">
      <h1 class="display-3">Our Achievements</h1>
      <div class="container-fluid">
        <img src="../img/boss.jpeg" class="img-fluid" alt="Responsive image">
    </div>
    <div class="scrollable text-center mt-3">
        <p>'Daija motor menjadi perusahaan paling besar nomor 1 di dunia.'</p>
    </div>

    <div class="container-fluid">
        <img src="../img/motor2.jpeg" class="img-fluid" alt="Responsive image">
    </div>
    <div class="scrollable text-center mt-3">
        <p>berhasil menjual 1 juta motor dalam 1 tahun</p>
    </div>
    </div>
  </div>
    <div class="scrollable text-center mt-3">
        <blockquote class="blockquote text-right">
            <footer class="blockquote-footer">Indah <cite title="Source Title">Rafael struick</cite></footer>
        </blockquote>
    </div>
</div>

</body>
</html>
