<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DAIJA MOTOR WEBSITE</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/navbars/">
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="../img/th.jpeg" alt="Logo motor" style="max-height: 60px; max-width: 140px;">
        </a>
        <!-- Link untuk menampilkan menu samping -->
        <a class="btn btn-dark btn-sm d-lg-none" data-bs-toggle="offcanvas" href="#offcanvasNavbar" role="button" aria-controls="offcanvasNavbar">
            <i class="bi bi-list"></i>
        </a>
        <!-- /Link untuk menampilkan menu samping -->

        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../profile/profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../visimisi/visimisi.php">Visi dan Misi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk/index.html">Produk kami</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Kontak Kami</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../about/about.php">About us</a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Login</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#">Sign in</a></li>
                        <li><a class="dropdown-item" href="#">Sign up</a></li>
                        <!-- Tambahkan submenu lain sesuai kebutuhan -->
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<br>
<main role="main">

  <!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="jumbotron">
    <div class="container">
      <h1 class="display-3">Daija Motor Store!</h1>
      <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
      <p><a class="btn btn-primary btn-lg" href="../profile/profile.php" role="button">lets see &raquo;</a></p>
    </div>
  </div>
  <div class="container">
    <!-- Example row of columns -->
    <div class="row">
      <div class="col-md-4">
        <h2>Sport</h2>
        <a class="navbar-brand" href="#">
            <img src="../img/motor1.jpeg" alt="Logo motor" style="max-height: 260px; max-width: 340px;">
        </a>
        <p>Motor sport adalah jenis motor yang dirancang untuk memberikan performa tinggi dan kecepatan maksimal di jalan raya. Mereka sering memiliki mesin yang kuat dan rangka yang ringan untuk meningkatkan kecepatan dan manuverabilitas. Motor sport 
            biasanya digunakan untuk balapan atau berkendara dengan kecepatan tinggi di jalan raya. Mereka memiliki postur berkendara yang cenderung menunduk dan agresif, dengan pegangan yang lebih 
            rendah dan posisi duduk yang cenderung lebih maju.</p>
        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
      </div>
      <div class="col-md-4">
        <h2>Cruiser</h2>
        <a class="navbar-brand" href="#">
            <img src="../img/motor2.jpeg" alt="Logo motor" style="max-height: 260px; max-width: 340px;">
        </a>
        <p>Motor cruiser adalah jenis motor yang dirancang untuk kenyamanan dan gaya berkendara yang santai. Mereka biasanya memiliki posisi duduk yang santai dengan pegangan tinggi dan posisi kaki yang di depan. Motor cruiser seringkali memiliki 
            mesin berkapasitas besar dengan torsi yang kuat, yang membuatnya cocok untuk perjalanan jarak jauh di jalan raya. Desain estetika motor cruiser cenderung menonjolkan gaya klasik atau retro, dengan bagian-bagian 
            seperti ban putih, tangki bahan bakar besar, dan lampu bundar.</p>
        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
      </div>
      <div class="col-md-4">
        <h2>Trail</h2>
        <a class="navbar-brand" href="#">
            <img src="../img/motor3.jpeg" alt="Logo motor" style="max-height: 260px; max-width: 340px;">
        </a>
        <p>Motor trail atau adventure adalah jenis motor yang dirancang untuk berkendara di berbagai medan, termasuk jalan aspal, tanah, dan medan off-road. Mereka memiliki suspensi yang tinggi dan kokoh untuk menangani berbagai jenis permukaan, serta ban 
            yang lebih besar dan lebih bertenaga untuk traksi yang lebih baik. Motor trail sering memiliki postur berkendara yang tegak, dengan posisi duduk yang nyaman dan pegangan yang tinggi. Mereka cocok untuk petualangan menjelajahi alam bebas atau berkendara 
            di jalanan perkotaan dengan kenyamanan dan keamanan ekstra.</p>
        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
      </div>
    </div>
